import os, zipfile, tempfile, urllib.request
import xbmc, xbmcgui, xbmcvfs

BUILD_URL = "https://drive.google.com/uc?id=1AcZRay-wyY4-UROFQZbqbIteDnqIh-60&export=download"
BUILD_NAME = "Nick Build"

def notify(msg, time=3000):
    xbmcgui.Dialog().notification("Nick Wizard", msg, xbmcgui.NOTIFICATION_INFO, time)

def download(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent":"Mozilla/5.0"})
    with urllib.request.urlopen(req) as r, open(dest, "wb") as f:
        total=0; dp = xbmcgui.DialogProgress(); dp.create("Downloading", BUILD_NAME)
        while True:
            chunk = r.read(1024*256)
            if not chunk: break
            f.write(chunk); total += len(chunk)
            mb = total//(1024*1024)
            dp.update(0, f"Downloaded {mb} MB…")
            if dp.iscanceled(): dp.close(); raise Exception("Cancelled")
        dp.close()

def extract(zip_path, target):
    dp = xbmcgui.DialogProgress(); dp.create("Installing", f"Extracting {BUILD_NAME}")
    with zipfile.ZipFile(zip_path, 'r') as z:
        members=z.namelist()
        total=len(members)
        for i, m in enumerate(members, 1):
            dp.update(int(i*100/total))
            out=os.path.join(target,m)
            if m.endswith('/'):
                xbmcvfs.mkdirs(out)
            else:
                xbmcvfs.mkdirs(os.path.dirname(out))
                with z.open(m) as src, xbmcvfs.File(out,'w') as dst:
                    dst.write(src.read())
    dp.close()

def main():
    if not xbmcgui.Dialog().yesno("Nick Wizard", f"Install {BUILD_NAME} now? Kodi will restart."):
        return
    zip_path=os.path.join(tempfile.gettempdir(),"kodi_build.zip")
    try:
        download(BUILD_URL, zip_path)
        extract(zip_path, xbmcvfs.translatePath("special://home"))
    except Exception as e:
        notify(f"Error: {e}")
        return
    xbmcgui.Dialog().ok("Nick Wizard","Install complete. Kodi will now close.")
    xbmc.executebuiltin('Quit')

if __name__=="__main__":
    main()
